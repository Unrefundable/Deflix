"""Tell a movie's title page that KDMM can resume it.

The skin's Resume button follows ListItem.IsResumable, which TMDb Bingie
Helper fills from Trakt's playback progress. That arrives some seconds after
playback stops, so the title page KDMM opens right after a stop showed "Play"
for a movie that was left half-way. KDMM keeps its own saved positions, and
those are what its Resume actually plays from.

The skin asks by sending NotifyAll(plugin.video.kdmm,resume_<tmdb id>_<imdb id>)
from a movie page's onload (the IMDb id may be empty). KDMM answers through
window properties; kdmm.resume.tmdb is set last and only when there is a
position to resume, so the skin compares it with the page's TMDb id.
"""

import xbmc
import xbmcgui

NOTIFY_PREFIX = "resume_"
PROP_TMDB = "kdmm.resume.tmdb"
PROP_TIME = "kdmm.resume.time"

_WIN = xbmcgui.Window(10000)


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[KDMM Resume] {msg}", level)


def parse_request(action):
    """(tmdb id, imdb id) from a resume_ notification, or None for other actions."""
    if not action.startswith(NOTIFY_PREFIX):
        return None
    tmdb_id, _, imdb_id = action[len(NOTIFY_PREFIX):].partition("_")
    return tmdb_id.strip(), imdb_id.strip()


class MovieResume:
    def __init__(self, progress_cache):
        self._progress = progress_cache

    def handle_notification(self, action):
        """True when the notification was a resume request."""
        request = parse_request(action)
        if request is None:
            return False
        tmdb_id, imdb_id = request
        if tmdb_id.isdigit():
            self.publish(tmdb_id, imdb_id)
        return True

    def publish(self, tmdb_id, imdb_id=""):
        _WIN.clearProperty(PROP_TMDB)
        try:
            position = self._progress.movie_position(tmdb_id, imdb_id)
        except Exception as exc:
            _log(f"Could not read saved positions: {exc}", xbmc.LOGWARNING)
            position = 0.0
        if position <= 0:
            _WIN.clearProperty(PROP_TIME)
            return False
        _WIN.setProperty(PROP_TIME, str(int(position)))
        _WIN.setProperty(PROP_TMDB, str(tmdb_id))
        return True
